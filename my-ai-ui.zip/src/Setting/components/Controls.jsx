import {
  useEffect,
  useRef,
  useState
} from "react";


function normalizeTextValue(value) {
  return value === null || value === undefined
    ? ""
    : String(value);
}

function useDraftTextValue(value, onChange) {
  const normalizedValue = normalizeTextValue(value);
  const [draftValue, setDraftValue] = useState(normalizedValue);
  const focusedRef = useRef(false);
  const composingRef = useRef(false);
  const externalValueRef = useRef(normalizedValue);

  useEffect(() => {
    externalValueRef.current = normalizedValue;

    if (!focusedRef.current && !composingRef.current) {
      setDraftValue(normalizedValue);
    }
  }, [normalizedValue]);

  const commitValue = (nextValue) => {
    externalValueRef.current = nextValue;
    setDraftValue(nextValue);
    onChange?.(nextValue);
  };

  return {
    value: draftValue,

    onFocus: () => {
      focusedRef.current = true;
    },

    onBlur: () => {
      focusedRef.current = false;

      queueMicrotask(() => {
        if (!focusedRef.current && !composingRef.current) {
          setDraftValue(externalValueRef.current);
        }
      });
    },

    onCompositionStart: () => {
      composingRef.current = true;
    },

    onCompositionEnd: (event) => {
      composingRef.current = false;
      commitValue(event.currentTarget.value);
    },

    onChange: (event) => {
      const nextValue = event.currentTarget.value;
      externalValueRef.current = nextValue;
      setDraftValue(nextValue);

      if (!composingRef.current) {
        onChange?.(nextValue);
      }
    }
  };
}

export function SettingsSection({
  title,
  children
}) {
  return (
    <section className="settings-section">
      <header className="settings-section__header">
        <h2>{title}</h2>

      </header>

      <div className="settings-section__body">
        {children}
      </div>
    </section>
  );
}

export function SettingRow({
  title,
  disabled = false,
  children
}) {
  return (
    <div
      className={
        `settings-row${
          disabled
            ? " is-disabled"
            : ""
        }`
      }
    >
      <div className="settings-row__copy">
        <div className="settings-row__title">
          {title}
        </div>

      </div>

      <div className="settings-row__control">
        {children}
      </div>
    </div>
  );
}

export function Toggle({
  checked,
  disabled = false,
  onChange,
  label,
  testId
}) {
  return (
    <button
      type="button"
      className={
        `settings-toggle${
          checked
            ? " is-on"
            : ""
        }`
      }
      role="switch"
      aria-checked={checked}
      aria-label={label}
      data-testid={testId}
      disabled={disabled}
      onClick={() => {
        onChange?.(!checked);
      }}
    >
      <span className="settings-toggle__thumb" />
    </button>
  );
}

export function Slider({
  value,
  min,
  max,
  step = 1,
  unit = "",
  formatValue,
  disabled = false,
  onChange
}) {
  const displayValue =
    formatValue
      ? formatValue(value)
      : `${value}${unit}`;

  return (
    <div className="settings-slider">
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(event) => {
          onChange?.(
            Number(
              event.target.value
            )
          );
        }}
      />

      <output>
        {displayValue}
      </output>
    </div>
  );
}

export function Select({
  value,
  options,
  disabled = false,
  onChange,
  testId
}) {
  return (
    <select
      className="settings-select"
      data-testid={testId}
      value={value}
      disabled={disabled}
      onChange={(event) => {
        const selected =
          options.find(
            (option) =>
              String(option.value) ===
              event.target.value
          );

        onChange?.(
          selected?.value ??
          event.target.value
        );
      }}
    >
      {options.map((option) => (
        <option
          key={String(option.value)}
          value={String(option.value)}
        >
          {option.label}
        </option>
      ))}
    </select>
  );
}

export function TextInput({
  value,
  placeholder,
  type = "text",
  disabled = false,
  autoComplete,
  list,
  onChange,
  testId
}) {
  const draft = useDraftTextValue(
    value,
    onChange
  );

  return (
    <input
      className="settings-text-input"
      data-testid={testId}
      type={type}
      value={draft.value}
      placeholder={placeholder}
      disabled={disabled}
      autoComplete={autoComplete}
      list={list}
      onFocus={draft.onFocus}
      onBlur={draft.onBlur}
      onCompositionStart={draft.onCompositionStart}
      onCompositionEnd={draft.onCompositionEnd}
      onChange={draft.onChange}
    />
  );
}

export function TextArea({
  value,
  placeholder,
  disabled = false,
  rows = 5,
  maxLength,
  onChange,
  testId
}) {
  const draft = useDraftTextValue(
    value,
    onChange
  );

  return (
    <textarea
      className="settings-textarea"
      data-testid={testId}
      value={draft.value}
      placeholder={placeholder}
      disabled={disabled}
      rows={rows}
      maxLength={maxLength}
      onFocus={draft.onFocus}
      onBlur={draft.onBlur}
      onCompositionStart={draft.onCompositionStart}
      onCompositionEnd={draft.onCompositionEnd}
      onChange={draft.onChange}
    />
  );
}

export function Segmented({
  value,
  options,
  disabled = false,
  onChange,
  testId
}) {
  return (
    <div
      className="settings-segmented"
      data-testid={testId}
      style={{
        "--segment-count":
          options.length
      }}
    >
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          disabled={disabled}
          className={
            `settings-segmented__item${
              value === option.value
                ? " is-active"
                : ""
            }`
          }
          onClick={() => {
            onChange?.(
              option.value
            );
          }}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function ColorSwatches({
  value,
  options,
  onChange
}) {
  const normalizedValue =
    /^#[0-9a-f]{6}$/i.test(value)
      ? value
      : "#10a37f";

  const isPreset =
    options.some(
      (option) =>
        option.value.toLowerCase() ===
        normalizedValue.toLowerCase()
    );

  return (
    <div className="settings-color-picker">
      <div className="settings-swatches">
        {options.map((option) => (
          <button
            key={option.value}
            type="button"
            className={
              `settings-swatch${
                normalizedValue
                  .toLowerCase() ===
                option.value
                  .toLowerCase()
                  ? " is-active"
                  : ""
              }`
            }
            style={{
              "--swatch-color":
                option.value
            }}
            title={option.label}
            aria-label={option.label}
            onClick={() => {
              onChange?.(
                option.value
              );
            }}
          >
            <span />
          </button>
        ))}
      </div>

      <div className="settings-custom-color-row">
        <label
          className={
            `settings-custom-color${
              !isPreset
                ? " is-active"
                : ""
            }`
          }
          title="打开系统调色盘"
        >
          <input
            type="color"
            value={normalizedValue}
            onChange={(event) => {
              onChange?.(
                event.target.value
              );
            }}
          />

          <span className="settings-custom-color__label">
            自定义颜色
          </span>
        </label>

        <output className="settings-color-value">
          {normalizedValue.toUpperCase()}
        </output>
      </div>
    </div>
  );
}

export function ActionButton({
  children,
  tone = "normal",
  disabled = false,
  testId,
  onClick
}) {
  return (
    <button
      type="button"
      className={
        `settings-action settings-action--${tone}`
      }
      data-testid={testId}
      disabled={disabled}
      onClick={onClick}
    >
      {children}
    </button>
  );
}

export function SettingsVisibility({
  visibility = "normal",
  developerMode = false,
  children
}) {
  if (
    visibility === "developer" &&
    !developerMode
  ) {
    return null;
  }

  return children;
}
