import {
  createBaseWindow
} from "../../core/createWindow.js";

import {
  getRendererUrl
} from "../../shared/rendererRoutes.js";

import {
  getSettings
} from "../../settings/settingsStore.js";

import {
  getPetWindow
} from "../pet/petWindow.js";

const INPUT_MIN_HEIGHT = 52;
const INPUT_VERTICAL_SPACE = 20;
const INPUT_TEXTAREA_VERTICAL_PADDING = 12;
const INPUT_CONTEXT_MENU_MAX_HEIGHT = 330;

let inputWindow = null;
let attachedPet = null;

let fixedInputWidth = null;
let logicalInputHeight =
  INPUT_MIN_HEIGHT;

let logicalInputBaseHeight =
  INPUT_MIN_HEIGHT;

let logicalMenuExtraHeight = 0;
let logicalMenuDirection = "down";
let logicalOverlayOpen = false;

let petMoveHandler = null;
let petResizeHandler = null;
let petClosedHandler = null;

function clamp(
  value,
  min,
  max
) {
  return Math.min(
    Math.max(value, min),
    max
  );
}

function getInputMetrics(
  settings = getSettings()
) {
  const input =
    settings.input;

  const lineHeight =
    Math.round(
      input.fontSize *
      1.45
    );

  return {
    gap:
      input.gap,

    extraWidth:
      input.extraWidth,

    minHeight:
      INPUT_MIN_HEIGHT,

    maxHeight:
      Math.max(
        INPUT_MIN_HEIGHT,
        input.maxLines *
          lineHeight +
          INPUT_TEXTAREA_VERTICAL_PADDING +
          INPUT_VERTICAL_SPACE +
          INPUT_CONTEXT_MENU_MAX_HEIGHT
      ),

    alwaysOnTop:
      input.alwaysOnTop
  };
}

function getAnchorBounds(
  settings = getSettings()
) {
  const pet = getPetWindow();

  if (
    !pet ||
    pet.isDestroyed()
  ) {
    return null;
  }

  const metrics =
    getInputMetrics(
      settings
    );

  const petBounds =
    pet.getBounds();

  return {
    x: Math.round(
      petBounds.x -
      metrics.extraWidth / 2
    ),

    y: Math.round(
      petBounds.y +
      petBounds.height +
      metrics.gap
    ),

    width: Math.round(
      petBounds.width +
      metrics.extraWidth
    )
  };
}

function applyInputBounds(
  settings = getSettings()
) {
  if (
    !inputWindow ||
    inputWindow.isDestroyed() ||
    !Number.isFinite(
      fixedInputWidth
    )
  ) {
    return;
  }

  const anchor =
    getAnchorBounds(
      settings
    );

  if (!anchor) {
    return;
  }

  inputWindow.setBounds(
    {
      x: anchor.x,
      y: logicalMenuDirection === "up"
        ? Math.round(anchor.y - logicalMenuExtraHeight)
        : anchor.y,

      width:
        fixedInputWidth,

      height:
        logicalInputHeight
    },
    false
  );
}

function updateSizeConstraints(
  settings
) {
  if (
    !inputWindow ||
    inputWindow.isDestroyed()
  ) {
    return;
  }

  const metrics =
    getInputMetrics(
      settings
    );

  const anchor =
    getAnchorBounds(
      settings
    );

  if (!anchor) {
    return;
  }

  fixedInputWidth =
    anchor.width;

  logicalInputHeight =
    Math.round(
      clamp(
        logicalInputHeight,
        metrics.minHeight,
        metrics.maxHeight
      )
    );

  logicalInputBaseHeight =
    Math.round(
      clamp(
        logicalInputBaseHeight,
        metrics.minHeight,
        metrics.maxHeight
      )
    );

  logicalMenuExtraHeight =
    Math.max(
      0,
      Math.min(
        logicalMenuExtraHeight,
        logicalInputHeight -
          metrics.minHeight
      )
    );

  inputWindow.setMinimumSize(
    1,
    1
  );

  inputWindow.setMaximumSize(
    10000,
    10000
  );

  inputWindow.setMinimumSize(
    fixedInputWidth,
    metrics.minHeight
  );

  inputWindow.setMaximumSize(
    fixedInputWidth,
    metrics.maxHeight
  );
}

function detachPetListeners() {
  if (
    attachedPet &&
    !attachedPet.isDestroyed()
  ) {
    if (petMoveHandler) {
      attachedPet.removeListener(
        "move",
        petMoveHandler
      );
    }

    if (petResizeHandler) {
      attachedPet.removeListener(
        "resize",
        petResizeHandler
      );
    }

    if (petClosedHandler) {
      attachedPet.removeListener(
        "closed",
        petClosedHandler
      );
    }
  }

  attachedPet = null;
  petMoveHandler = null;
  petResizeHandler = null;
  petClosedHandler = null;
}

export function openInputWindow() {
  if (
    inputWindow &&
    !inputWindow.isDestroyed()
  ) {
    inputWindow.show();
    inputWindow.focus();

    return inputWindow;
  }

  const pet = getPetWindow();
  const settings =
    getSettings();

  const metrics =
    getInputMetrics(
      settings
    );

  const anchor =
    getAnchorBounds(
      settings
    );

  if (
    !pet ||
    pet.isDestroyed() ||
    !anchor
  ) {
    return null;
  }

  fixedInputWidth =
    anchor.width;

  logicalInputHeight =
    metrics.minHeight;

  logicalInputBaseHeight =
    metrics.minHeight;

  logicalMenuExtraHeight = 0;
  logicalMenuDirection = "down";
  logicalOverlayOpen = false;

  inputWindow =
    createBaseWindow({
      x: anchor.x,
      y: anchor.y,

      width:
        fixedInputWidth,

      height:
        logicalInputHeight,

      minWidth:
        fixedInputWidth,

      maxWidth:
        fixedInputWidth,

      minHeight:
        metrics.minHeight,

      maxHeight:
        metrics.maxHeight,

      show: false,

      transparent: true,

      backgroundColor:
        "#00000000",

      /*
       * 关闭原生矩形阴影，避免大圆角时在透明四角露出灰层。
       */
      hasShadow: false,

      resizable: false,
      minimizable: false,
      maximizable: false,
      fullscreenable: false,

      skipTaskbar: true,

      alwaysOnTop:
        metrics.alwaysOnTop
    });

  inputWindow.loadURL(
    getRendererUrl("/input")
  );

  inputWindow.once(
    "ready-to-show",
    () => {
      if (
        !inputWindow ||
        inputWindow.isDestroyed()
      ) {
        return;
      }

      inputWindow.show();
      inputWindow.focus();
    }
  );

  attachedPet = pet;

  petMoveHandler = () => {
    applyInputBounds();
  };

  petResizeHandler = () => {
    applyInputWindowSettings(
      getSettings()
    );
  };

  petClosedHandler = () => {
    closeInputWindow();
  };

  pet.on(
    "move",
    petMoveHandler
  );

  pet.on(
    "resize",
    petResizeHandler
  );

  pet.on(
    "closed",
    petClosedHandler
  );

  inputWindow.on(
    "closed",
    () => {
      detachPetListeners();

      inputWindow = null;
      fixedInputWidth = null;

      logicalInputHeight =
        INPUT_MIN_HEIGHT;

      logicalInputBaseHeight =
        INPUT_MIN_HEIGHT;

      logicalMenuExtraHeight = 0;
      logicalMenuDirection = "down";
      logicalOverlayOpen = false;
    }
  );

  return inputWindow;
}

export function applyInputWindowSettings(
  settings
) {
  if (
    !inputWindow ||
    inputWindow.isDestroyed()
  ) {
    return;
  }

  const metrics =
    getInputMetrics(
      settings
    );

  updateSizeConstraints(
    settings
  );

  if (logicalOverlayOpen) {
    inputWindow.setAlwaysOnTop(true, "pop-up-menu");
    inputWindow.moveTop();
  } else {
    inputWindow.setAlwaysOnTop(metrics.alwaysOnTop);
  }

  applyInputBounds(
    settings
  );
}

export function resizeInputWindow(
  request
) {
  if (
    !inputWindow ||
    inputWindow.isDestroyed() ||
    !Number.isFinite(
      fixedInputWidth
    )
  ) {
    return;
  }

  const normalized =
    request &&
    typeof request === "object"
      ? request
      : {
          height: request,
          baseHeight: request,
          menuExtraHeight: 0,
          menuDirection: "down",
          overlayOpen: false
        };

  const numericHeight =
    Number(normalized.height);

  const numericBaseHeight =
    Number(normalized.baseHeight);

  const numericMenuExtraHeight =
    Number(normalized.menuExtraHeight);

  const nextMenuDirection =
    normalized.menuDirection === "up"
      ? "up"
      : "down";

  const nextOverlayOpen =
    normalized.overlayOpen === true;

  if (
    !Number.isFinite(
      numericHeight
    ) ||
    !Number.isFinite(
      numericBaseHeight
    )
  ) {
    return;
  }

  const settings =
    getSettings();

  const metrics =
    getInputMetrics(
      settings
    );

  logicalInputBaseHeight =
    Math.round(
      clamp(
        numericBaseHeight,
        metrics.minHeight,
        metrics.maxHeight
      )
    );

  logicalMenuExtraHeight =
    Math.max(
      0,
      Math.min(
        Number.isFinite(
          numericMenuExtraHeight
        )
          ? numericMenuExtraHeight
          : numericHeight -
            logicalInputBaseHeight,
        INPUT_CONTEXT_MENU_MAX_HEIGHT
      )
    );

  logicalInputHeight =
    Math.round(
      clamp(
        Math.max(
          numericHeight,
          logicalInputBaseHeight +
            logicalMenuExtraHeight
        ),
        metrics.minHeight,
        metrics.maxHeight
      )
    );

  logicalMenuDirection =
    nextOverlayOpen
      ? nextMenuDirection
      : "down";

  logicalOverlayOpen = nextOverlayOpen;

  if (logicalOverlayOpen) {
    inputWindow.setAlwaysOnTop(true, "pop-up-menu");
    inputWindow.moveTop();
  } else {
    inputWindow.setAlwaysOnTop(metrics.alwaysOnTop);
  }

  applyInputBounds(
    settings
  );
}

export function isInputSender(
  webContents
) {
  return Boolean(
    inputWindow &&
    !inputWindow.isDestroyed() &&
    inputWindow.webContents ===
      webContents
  );
}

export function closeInputWindow() {
  if (
    !inputWindow ||
    inputWindow.isDestroyed()
  ) {
    return;
  }

  inputWindow.close();
}
