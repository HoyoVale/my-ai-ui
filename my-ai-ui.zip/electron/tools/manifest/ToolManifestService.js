import crypto from "node:crypto";

import {
  resolveActiveModelSettings
} from "../../settings/modelSettings.js";

import {
  getWorkspaceRoots
} from "../workspace/workspacePolicy.js";

import {
  baseToolsetEnabled,
  resolveEnabledToolCatalog,
  resolveToolMode
} from "../toolCatalog.js";

import {
  BUILTIN_TOOLSET_MANIFEST,
  getBuiltinToolsetManifest
} from "./builtinToolPresentation.js";

import {
  createBuiltinToolRegistry
} from "./createBuiltinToolRegistry.js";

import {
  mcpClientManager
} from "../../mcp/McpClientManager.js";

import {
  declarativeHttpToolManager
} from "../../custom-tools/DeclarativeHttpToolManager.js";

import {
  resolveCapabilitySet
} from "../capabilities/CapabilityResolver.js";

import {
  toolManifestRevisionTracker
} from "../capabilities/ToolManifestRevisionTracker.js";

const OVERRIDE_VALUES = new Set([
  "inherit",
  "enabled",
  "disabled"
]);

function overrideValue(value) {
  return OVERRIDE_VALUES.has(value) ? value : "inherit";
}

function stableHash(value) {
  return crypto
    .createHash("sha256")
    .update(JSON.stringify(value))
    .digest("hex")
    .slice(0, 20);
}

function resolveActiveModel(settings) {
  try {
    return resolveActiveModelSettings(settings.model);
  } catch {
    return null;
  }
}

function toolAvailability(tool, settings) {
  const toolSettings = settings.tools ?? {};
  const workspaceSettings = toolSettings.workspace ?? {};
  const mode = resolveToolMode(toolSettings);
  const toolset = tool.toolsets?.[0] ?? "core.runtime";
  const roots = getWorkspaceRoots(workspaceSettings);

  if (String(tool.source ?? "").startsWith("mcp.")) {
    const serverId = String(tool.source).slice(4);
    const serverState = mcpClientManager
      .snapshot()
      .servers
      .find((server) => server.id === serverId);
    if (!serverState || serverState.enabled === false) {
      return {
        available: false,
        reason: "对应的 MCP Server 未启用。"
      };
    }
    if (serverState.state === "error") {
      return {
        available: false,
        reason: serverState.error || "MCP Server 连接失败。"
      };
    }
    if (tool.mcp?.permission?.allowed === false) {
      return {
        available: false,
        reason: tool.mcp.permission.reason || "该 MCP 工具未获授权。"
      };
    }
  }

  if (String(tool.source ?? "").startsWith("custom.http.")) {
    const customId = String(tool.source).slice("custom.http.".length);
    const config = (settings.customTools?.tools ?? []).find(
      (item) => item.id === customId
    );
    if (settings.customTools?.enabled === false) {
      return {
        available: false,
        reason: "自定义工具已全局关闭。"
      };
    }
    if (!config || config.enabled === false) {
      return {
        available: false,
        reason: "该自定义 HTTP 工具未启用。"
      };
    }
    if (!config.url) {
      return {
        available: false,
        reason: "尚未配置请求地址。"
      };
    }
    if (config.method === "DELETE" && config.allowDestructive !== true) {
      return {
        available: false,
        reason: "DELETE 工具需要在开发者模式下显式允许破坏性操作。"
      };
    }
  }

  if (toolset.startsWith("workspace.") && roots.length === 0) {
    return {
      available: false,
      reason: "当前没有绑定工作区。"
    };
  }

  if (toolset === "workspace.write" && mode !== "coding") {
    return {
      available: false,
      reason: "工作区写入仅在 Coding 模式可用。"
    };
  }

  if (toolset === "workspace.exec") {
    const toolsetOverride = overrideValue(
      toolSettings.developer?.toolsetOverrides?.[toolset]
    );
    if (toolsetOverride !== "enabled") {
      return {
        available: false,
        reason: "工作区进程工具需要开发者显式强制启用。"
      };
    }
  }

  if (
    tool.name === "run_workspace_command" &&
    (workspaceSettings.allowedCommands ?? []).length === 0
  ) {
    return {
      available: false,
      reason: "尚未配置允许执行的命令。"
    };
  }

  return {
    available: true,
    reason: ""
  };
}

function toolsetEffectiveState(toolsetId, settings) {
  const toolSettings = settings.tools ?? {};
  const mode = resolveToolMode(toolSettings);
  const override = overrideValue(
    toolSettings.developer?.toolsetOverrides?.[toolsetId]
  );
  let enabled = baseToolsetEnabled(mode, toolsetId);

  if (override === "enabled") {
    enabled = true;
  } else if (override === "disabled") {
    enabled = false;
  }

  if (toolsetId === "workspace.write" && mode !== "coding") {
    enabled = false;
  }
  if (toolsetId === "workspace.exec" && override !== "enabled") {
    enabled = false;
  }
  if (toolSettings.enabled === false) {
    enabled = false;
  }

  return {
    override,
    enabled
  };
}

export function getToolManifestSnapshot({
  settings = {},
  executionContext = null,
  capabilityRequest = null
} = {}) {
  const toolSettings = settings.tools ?? {};
  const activeModel = resolveActiveModel(settings);
  const registry = createBuiltinToolRegistry({
    activeModel,
    settings,
    workspaceSettings: toolSettings.workspace ?? {},
    includeWorkspaceDefinitions: true,
    includeWorkspaceInfo: true
  });
  registry.registerMany(
    mcpClientManager.getToolDefinitions(null, { includeDenied: true })
  );
  registry.registerMany(
    declarativeHttpToolManager.getToolDefinitions(settings, {
      includeDisabled: true
    })
  );
  const rawTools = registry.manifest();
  const enabledNames = new Set(
    resolveEnabledToolCatalog(toolSettings, rawTools).map((tool) => tool.name)
  );

  const baseTools = rawTools.map((tool) => {
    const toolsetId = tool.toolsets?.[0] ?? "core.runtime";
    const presentation = tool.presentation ?? {};
    const availability = toolAvailability(tool, settings);
    const override = overrideValue(
      toolSettings.developer?.toolOverrides?.[tool.name]
    );
    const effectiveEnabled = enabledNames.has(tool.name);

    return {
      ...tool,
      toolsetId,
      displayTitle: presentation.title || tool.title || tool.name,
      displayDescription: presentation.description || tool.description || "",
      sourceKind: tool.source?.startsWith("mcp.")
        ? "mcp"
        : tool.source?.startsWith("builtin.")
          ? "builtin"
          : "custom",
      builtIn: tool.source?.startsWith("builtin.") === true,
      override,
      effectiveEnabled,
      available: availability.available,
      availabilityReason: availability.reason,
      ready: effectiveEnabled && availability.available,
      editable: {
        implementation: false,
        schema: false,
        description: false,
        override: true
      }
    };
  });

  const capabilityResolution = resolveCapabilitySet({
    tools: baseTools,
    mode: resolveToolMode(toolSettings),
    workspaceAvailable: getWorkspaceRoots(toolSettings.workspace ?? {}).length > 0,
    settings,
    request:
      capabilityRequest && typeof capabilityRequest === "object"
        ? capabilityRequest
        : executionContext?.capabilityRequest ?? {}
  });

  const tools = baseTools.map((tool) => {
    const permissionResolution = capabilityResolution.toolDecisions[tool.name] ?? {
      allowed: false,
      requiresApproval: false,
      ready: false,
      permissions: [],
      deniedPermissions: [],
      approvalPermissions: []
    };
    return {
      ...tool,
      permissionResolution,
      ready: tool.ready && permissionResolution.allowed
    };
  });

  const toolsets = BUILTIN_TOOLSET_MANIFEST.map((item) => {
    const state = toolsetEffectiveState(item.id, settings);
    const members = tools.filter((tool) => tool.toolsetId === item.id);
    return {
      ...item,
      ...state,
      toolCount: members.length,
      enabledToolCount: members.filter((tool) => tool.ready).length,
      tools: members
    };
  });

  const unknownToolsets = [...new Set(
    tools.map((tool) => tool.toolsetId)
      .filter((id) => !getBuiltinToolsetManifest(id))
  )].map((id, index) => {
    const state = toolsetEffectiveState(id, settings);
    const members = tools.filter((tool) => tool.toolsetId === id);
    return {
      id,
      title: id,
      description: "外接工具组",
      riskLabel: "外接",
      userVisible: true,
      order: 1000 + index,
      ...state,
      toolCount: members.length,
      enabledToolCount: members.filter((tool) => tool.ready).length,
      tools: members
    };
  });

  const result = {
    schemaVersion: 1,
    generatedAt: Date.now(),
    mode: resolveToolMode(toolSettings),
    executionContext: executionContext && typeof executionContext === "object"
      ? structuredClone(executionContext)
      : null,
    activeModel: activeModel
      ? {
          providerId: activeModel.providerId,
          providerName: activeModel.providerName,
          modelConfigId: activeModel.modelConfigId,
          modelName: activeModel.modelName,
          modelId: activeModel.model
        }
      : null,
    globalEnabled: toolSettings.enabled !== false,
    capabilityResolution: {
      ...capabilityResolution,
      toolDecisions: structuredClone(capabilityResolution.toolDecisions)
    },
    capabilitySummary: structuredClone(capabilityResolution.summary),
    permissionEnvelope: structuredClone(capabilityResolution.permissions),
    sourceSummary: {
      builtin: tools.filter((tool) => tool.sourceKind === "builtin").length,
      mcp: tools.filter((tool) => tool.sourceKind === "mcp").length,
      custom: tools.filter((tool) => tool.sourceKind === "custom").length
    },
    toolsets: [...toolsets, ...unknownToolsets]
      .sort((left, right) => (left.order ?? 0) - (right.order ?? 0)),
    tools
  };

  const manifestHash = stableHash({
    schemaVersion: result.schemaVersion,
    mode: result.mode,
    globalEnabled: result.globalEnabled,
    toolsets: result.toolsets,
    tools: result.tools,
    capabilityResolution: result.capabilityResolution,
    permissionEnvelope: result.permissionEnvelope
  });
  const revisionState = toolManifestRevisionTracker.observe(
    executionContext?.conversationId || `preview:${result.mode}`,
    manifestHash
  );

  return {
    ...result,
    revision: manifestHash,
    manifestHash,
    manifestRevision: revisionState.revision,
    manifestChanged: revisionState.changed
  };
}
