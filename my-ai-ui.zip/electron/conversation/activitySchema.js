import {
  normalizeRunStopReason,
  runStatusFromStopReason
} from "../agent/runStopReasons.js";

function stringValue(
  value,
  fallback = "",
  maxLength = 200000
) {
  return typeof value === "string"
    ? value.slice(0, maxLength)
    : fallback;
}

function timestampValue(value, fallback = 0) {
  const numeric = Number(value);

  return Number.isFinite(numeric)
    ? Math.max(0, Math.round(numeric))
    : fallback;
}

function jsonValue(value, maxLength = 50000) {
  if (value === undefined) {
    return undefined;
  }

  try {
    const text = JSON.stringify(value);

    if (text.length <= maxLength) {
      return JSON.parse(text);
    }

    return {
      truncated: true,
      preview: text.slice(0, maxLength)
    };
  } catch {
    return String(value).slice(0, maxLength);
  }
}

function normalizeToolStatus(value) {
  if (value === "queued") {
    return "queued";
  }

  if (["running", "in_progress", "retrying"].includes(value)) {
    return value === "retrying"
      ? "retrying"
      : "running";
  }

  if (["cancelled", "aborted"].includes(value)) {
    return "cancelled";
  }

  if (["failed", "error"].includes(value)) {
    return "failed";
  }

  if ([
    "unknown",
    "needs_reconciliation",
    "needs_confirmation",
    "attention"
  ].includes(value)) {
    return "attention";
  }

  return "completed";
}

function sanitizePlanItem(source, index) {
  if (!source || typeof source !== "object") {
    return null;
  }

  const title = stringValue(
    source.title,
    "",
    200
  ).trim();

  if (!title) {
    return null;
  }

  const allowed = new Set([
    "pending",
    "in_progress",
    "completed",
    "blocked",
    "needs_input",
    "skipped",
    "cancelled",
    "superseded"
  ]);

  return {
    id:
      stringValue(
        source.id,
        `step-${index + 1}`,
        80
      ) || `step-${index + 1}`,
    title,
    status: allowed.has(source.status)
      ? source.status
      : "pending",
    reason: stringValue(
      source.reason,
      "",
      300
    ).trim()
  };
}

function sanitizeToolResult(source) {
  if (!source || typeof source !== "object") {
    return null;
  }

  const status = [
    "success",
    "error",
    "cancelled"
  ].includes(source.status)
    ? source.status
    : source.error
      ? "error"
      : "success";

  const result = {
    status,
    summary: stringValue(
      source.summary,
      "",
      400
    ),
    preview: stringValue(
      source.preview,
      "",
      2400
    ),
    truncated: Boolean(source.truncated),
    originalBytes: timestampValue(
      source.originalBytes,
      0
    ),
    storedBytes: timestampValue(
      source.storedBytes,
      0
    ),
    clipped: Boolean(source.clipped)
  };

  const changePreview = jsonValue(source.changePreview, 26000);
  if (changePreview !== undefined) {
    result.changePreview = changePreview;
  }

  const data = jsonValue(source.data, 32000);
  const error = jsonValue(source.error, 8000);
  const reference = jsonValue(
    source.reference,
    1000
  );

  if (data !== undefined) {
    result.data = data;
  }

  if (error !== undefined) {
    result.error = error;
  }

  if (reference !== undefined) {
    result.reference = reference;
  }

  return result;
}

export function sanitizeActivityTool(
  source,
  index = 0
) {
  if (!source || typeof source !== "object") {
    return null;
  }

  const name = stringValue(
    source.name,
    "",
    120
  ).trim();

  if (!name) {
    return null;
  }

  const tool = {
    id:
      stringValue(
        source.id,
        `tool-${index + 1}`,
        120
      ) || `tool-${index + 1}`,
    name,
    title: stringValue(
      source.title,
      "",
      200
    ),
    status: normalizeToolStatus(
      source.status
    ),
    queuedAt: timestampValue(
      source.queuedAt,
      0
    ),
    startedAt: timestampValue(
      source.startedAt,
      0
    ),
    endedAt: timestampValue(
      source.endedAt,
      0
    ),
    durationMs: timestampValue(
      source.durationMs,
      0
    ),
    batchId: stringValue(
      source.batchId,
      "",
      160
    ),
    batchObjective: stringValue(
      source.batchObjective,
      "",
      240
    ),
    source: stringValue(
      source.source,
      "",
      120
    ),
    riskLevel: stringValue(
      source.riskLevel,
      "none",
      40
    ),
    sideEffect: stringValue(
      source.sideEffect,
      "none",
      40
    ),
    countsTowardLimit:
      source.countsTowardLimit !== false,
    countsTowardRepeatLimit:
      source.countsTowardRepeatLimit !== false,
    activityVisibility:
      source.activityVisibility === "developer"
        ? "developer"
        : "normal",
    gracefulBoundary:
      source.gracefulBoundary === true,
    attempt: timestampValue(
      source.attempt,
      0
    ),
    maxAttempts: timestampValue(
      source.maxAttempts,
      0
    )
  };

  const input = jsonValue(source.input, 24000);
  const output = jsonValue(source.output, 24000);
  const meta = jsonValue(source.meta, 8000);
  const runtime = jsonValue(source.runtime, 8000);
  const runtimeContract = jsonValue(source.runtimeContract, 4000);
  const result = sanitizeToolResult(
    source.result
  );
  const lastError = jsonValue(
    source.lastError,
    8000
  );
  const planStep =
    source.planStep &&
    typeof source.planStep === "object"
      ? {
          id: stringValue(
            source.planStep.id,
            "",
            80
          ),
          title: stringValue(
            source.planStep.title,
            "",
            200
          )
        }
      : null;

  if (input !== undefined) {
    tool.input = input;
  }

  if (output !== undefined) {
    tool.output = output;
  }

  if (meta !== undefined) {
    tool.meta = meta;
  }

  if (runtime !== undefined) {
    tool.runtime = runtime;
  }

  if (runtimeContract !== undefined) {
    tool.runtimeContract = runtimeContract;
  }

  if (result) {
    tool.result = result;
  }

  if (lastError !== undefined) {
    tool.lastError = lastError;
  }

  if (
    planStep?.id ||
    planStep?.title
  ) {
    tool.planStep = planStep;
  }

  return tool;
}

function sanitizeActivityEvent(source, index) {
  if (!source || typeof source !== "object") {
    return null;
  }

  const type = [
    "status",
    "tool",
    "plan",
    "commentary",
    "batch",
    "skill"
  ].includes(source.type)
    ? source.type
    : null;

  if (!type) {
    return null;
  }

  const eventId =
    stringValue(
      source.id,
      `event-${index + 1}`,
      160
    ) || `event-${index + 1}`;
  const runtimeLifecycle =
    type === "status" &&
    (
      source.category === "runtime" ||
      eventId.startsWith("progress:") ||
      eventId.startsWith("run:")
    );

  const event = {
    id: eventId,
    type,
    sequence: timestampValue(
      source.sequence,
      index
    ),
    status: stringValue(
      source.status,
      "completed",
      40
    ),
    title: stringValue(
      source.title,
      "",
      240
    ),
    createdAt: timestampValue(
      source.createdAt,
      0
    ),
    updatedAt: timestampValue(
      source.updatedAt,
      timestampValue(source.createdAt, 0)
    ),
    batchId: stringValue(
      source.batchId,
      "",
      160
    ),
    category:
      runtimeLifecycle
        ? "runtime"
        : "work",
    activityVisibility:
      runtimeLifecycle ||
      source.activityVisibility === "developer"
        ? "developer"
        : "normal"
  };

  if (type === "tool") {
    const tool = sanitizeActivityTool(
      source.tool,
      index
    );

    if (!tool) {
      return null;
    }

    event.tool = tool;
    event.status = tool.status;
  }

  if (type === "skill") {
    const skill = source.skill && typeof source.skill === "object"
      ? {
          id: stringValue(source.skill.id, "", 120).trim(),
          name: stringValue(source.skill.name, source.skill.id ?? "Skill", 120).trim(),
          version: stringValue(source.skill.version, "", 80).trim(),
          source: ["manual", "command", "router", "dependency", "none"].includes(source.skill.source)
            ? source.skill.source
            : "manual",
          skills: Array.isArray(source.skill.skills)
            ? source.skill.skills.map((item) => ({
                id: stringValue(item?.id, "", 120).trim(),
                name: stringValue(item?.name, item?.id ?? "Skill", 120).trim(),
                version: stringValue(item?.version, "", 80).trim(),
                requiredCapabilities: Array.isArray(item?.requiredCapabilities)
                  ? item.requiredCapabilities.map((value) => stringValue(value, "", 160).trim()).filter(Boolean).slice(0, 32)
                  : [],
                optionalCapabilities: Array.isArray(item?.optionalCapabilities)
                  ? item.optionalCapabilities.map((value) => stringValue(value, "", 160).trim()).filter(Boolean).slice(0, 32)
                  : []
              })).filter((item) => item.id).slice(0, 12)
            : [],
          router: source.skill.router && typeof source.skill.router === "object"
            ? structuredClone(source.skill.router)
            : null,
          requiredCapabilities: Array.isArray(source.skill.requiredCapabilities)
            ? source.skill.requiredCapabilities.map((item) => stringValue(item, "", 160).trim()).filter(Boolean).slice(0, 32)
            : [],
          optionalCapabilities: Array.isArray(source.skill.optionalCapabilities)
            ? source.skill.optionalCapabilities.map((item) => stringValue(item, "", 160).trim()).filter(Boolean).slice(0, 32)
            : [],
          selectedToolNames: Array.isArray(source.skill.selectedToolNames)
            ? source.skill.selectedToolNames.map((item) => stringValue(item, "", 160).trim()).filter(Boolean).slice(0, 100)
            : [],
          missingRequired: Array.isArray(source.skill.missingRequired)
            ? source.skill.missingRequired.map((item) => stringValue(item, "", 160).trim()).filter(Boolean).slice(0, 32)
            : []
        }
      : null;

    if (!skill?.id) {
      return null;
    }
    event.skill = skill;
  }

  if (type === "plan") {
    const plan = Array.isArray(source.plan)
      ? source.plan
          .map(sanitizePlanItem)
          .filter(Boolean)
          .slice(0, 20)
      : [];

    event.plan = plan;
    event.reason = stringValue(
      source.reason,
      "",
      500
    ).trim();
    event.revision = timestampValue(
      source.revision,
      0
    );
    event.rootRevision = timestampValue(
      source.rootRevision,
      event.revision
    );
    event.scope =
      source.scope === "step_work"
        ? "step_work"
        : "root";
  }

  if (type === "commentary") {
    event.content = stringValue(
      source.content,
      "",
      4000
    ).trim();
    event.phase = [
      "before_tools",
      "between_tools",
      "after_tools"
    ].includes(source.phase)
      ? source.phase
      : "between_tools";

    if (!event.content) {
      return null;
    }
  }

  if (type === "batch") {
    const batch = source.batch && typeof source.batch === "object"
      ? {
          id: stringValue(source.batch.id, event.id, 160),
          objective: stringValue(source.batch.objective, event.title, 240),
          status: stringValue(source.batch.status, event.status, 40),
          startedAt: timestampValue(source.batch.startedAt, event.createdAt),
          endedAt:
            source.batch.endedAt === null
              ? null
              : timestampValue(source.batch.endedAt, 0)
        }
      : null;

    if (!batch?.id) {
      return null;
    }

    event.batch = batch;
    event.batchId = batch.id;
  }

  if (type === "status") {
    event.stopReason = normalizeRunStopReason(
      source.stopReason,
      "unknown"
    );
  }

  return event;
}

function sanitizeCheckpoint(source) {
  if (
    !source ||
    typeof source !== "object"
  ) {
    return null;
  }

  const checkpoint = jsonValue(
    source,
    48000
  );

  if (
    !checkpoint ||
    typeof checkpoint !== "object"
  ) {
    return null;
  }

  const sanitizedCheckpoint = {
    ...checkpoint
  };
  delete sanitizedCheckpoint.answeredQuestions;
  delete sanitizedCheckpoint.pendingQuestion;

  return {
    ...sanitizedCheckpoint,
    version: Math.max(1, Math.round(Number(checkpoint.version) || 1)),
    taskId: stringValue(
      checkpoint.taskId,
      "",
      120
    ),
    runId: stringValue(
      checkpoint.runId,
      "",
      120
    ),
    messageId: stringValue(
      checkpoint.messageId,
      "",
      120
    ),
    phase: stringValue(
      checkpoint.phase,
      "executing",
      40
    ),
    outcome: stringValue(
      checkpoint.outcome,
      "running",
      40
    ),
    resumable:
      checkpoint.resumable === true,
    publicStatus: stringValue(
      checkpoint.publicStatus,
      "running",
      40
    ),
    stopReason: stringValue(
      checkpoint.stopReason,
      "",
      80
    ),
    updatedAt: timestampValue(
      checkpoint.updatedAt,
      0
    )
  };
}

export function sanitizeActivity(source) {
  if (!source || typeof source !== "object") {
    return null;
  }

  const stopReason = normalizeRunStopReason(
    source.stopReason,
    "unknown"
  );
  const status = [
    "running",
    "completed",
    "needs_input",
    "blocked",
    "cancelling",
    "cancelled",
    "interrupted",
    "checkpoint_ready",
    "failed",
    "unknown",
    "resumed"
  ].includes(source.status)
    ? source.status
    : runStatusFromStopReason(stopReason);
  const events = Array.isArray(source.events)
    ? source.events
        .map(sanitizeActivityEvent)
        .filter(Boolean)
        .slice(0, 240)
    : [];

  events.sort((left, right) => {
    if (left.createdAt !== right.createdAt) {
      return left.createdAt - right.createdAt;
    }

    return left.sequence - right.sequence;
  });

  return {
    version: 3,
    taskId: stringValue(
      source.taskId,
      "",
      120
    ),
    runId: stringValue(
      source.runId,
      "",
      120
    ),
    status,
    outcome: stringValue(
      source.outcome,
      status === "checkpoint_ready"
        ? "continuable"
        : status,
      40
    ),
    startedAt: timestampValue(
      source.startedAt,
      0
    ),
    endedAt:
      source.endedAt === null
        ? null
        : timestampValue(
            source.endedAt,
            0
          ),
    durationMs: timestampValue(
      source.durationMs,
      0
    ),
    stopReason,
    resumable:
      source.resumable === true ||
      status === "checkpoint_ready",
    completionState:
      status === "checkpoint_ready"
        ? "partial"
        : "terminal",
    checkpoint:
      sanitizeCheckpoint(
        source.checkpoint
      ),
    events
  };
}

export function createLegacyActivity({
  messageId,
  createdAt,
  durationMs = 0,
  toolCalls = [],
  plan = [],
  stopReason = "completed",
  taskId = ""
} = {}) {
  const normalizedReason = normalizeRunStopReason(
    stopReason,
    "completed"
  );
  const endedAt = timestampValue(
    createdAt,
    Date.now()
  );
  const startedAt = Math.max(
    0,
    endedAt - timestampValue(durationMs, 0)
  );
  const events = [];
  let sequence = 0;

  if (plan.length > 0) {
    events.push({
      id: `legacy-plan:${messageId}`,
      type: "plan",
      sequence: sequence++,
      status: "completed",
      title: `任务计划 · ${plan.length} 步`,
      createdAt: startedAt,
      updatedAt: endedAt,
      plan
    });
  }

  for (const tool of toolCalls) {
    events.push({
      id: `tool:${tool.id}`,
      type: "tool",
      sequence: sequence++,
      status: normalizeToolStatus(tool.status),
      title: tool.title || tool.name,
      createdAt:
        tool.queuedAt ||
        tool.startedAt ||
        startedAt,
      updatedAt:
        tool.endedAt ||
        endedAt,
      tool
    });
  }

  events.push({
    id: `legacy-status:${messageId}`,
    type: "status",
    sequence,
    status: runStatusFromStopReason(
      normalizedReason
    ),
    title: normalizedReason,
    stopReason: normalizedReason,
    createdAt: startedAt,
    updatedAt: endedAt
  });

  return sanitizeActivity({
    version: 1,
    taskId: taskId || messageId,
    runId: messageId,
    status: runStatusFromStopReason(
      normalizedReason
    ),
    startedAt,
    endedAt,
    durationMs: timestampValue(durationMs, 0),
    stopReason: normalizedReason,
    events
  });
}

export function deriveLegacyActivityFields(activity) {
  const normalized = sanitizeActivity(activity);

  if (!normalized) {
    return {
      plan: [],
      toolCalls: []
    };
  }

  const planEvent = [...normalized.events]
    .reverse()
    .find((event) => event.type === "plan");
  const toolCalls = normalized.events
    .filter((event) => event.type === "tool")
    .map((event) => event.tool);


  return {
    plan: planEvent?.plan ?? [],
    toolCalls
  };
}
